<?php
include_once 'C:\xampp\htdocs\zc_cafetria\PHPF\connectDataBase.php';
//Sign in
$username;
$password;
$AccountType;


$result1 = SignIn($username, $password);

if($result1)
{
    while($row = mysqli_fetch_assoc($result1))
    {
        $AccountType =  $row['Type'];
        
    }
}
//--------------------------------------------------------------
//all Products info in arabic
$ProductNumber;$ArabicName; $SellingPrice; $Quantity;
$result2 = ProductArabiaInfo();
if($result2)
{
    while($row = mysqli_fetch_assoc($result2))
    {
        $ProductNumber =  $row['PNumber'];
        $ArabicName =  $row['ArabicName'];
        $SellingPrice =  $row['SellingPrice'];
        $Quantity =  $row['Quantity'];
    }
}
//----------------------------------------------------
//ProductBarCodeInfo
$barcode;
$result3 = ProductBarCodeInfo($barcode);
if($result3)
{
    while($row = mysqli_fetch_assoc($result3))
    {
        $ProductNumber =  $row['PNumber'];
        $ArabicName =  $row['ArabicName'];
        $SellingPrice =  $row['SellingPrice'];
        $Quantity =  $row['Quantity'];
    }
}
//-----------------------------------------------------
//Order:
$result4 = createOrder();

$OrderNumber;
$result5 = KnowOrder();
if($result5)
{
    while($row = mysqli_fetch_assoc($result5))
    {
        $OrderNumber =  $row['Number'];
    }
}

$result6 = decrease_quantity($Quantity , $ProductNumber);
//$cashCash += calculateTotalCash($SellingPrice, $Quantity);
function calculateTotalCash($SellingPrice, $Quantity)
{
    return $SellingPrice * $Quantity;
}

$result7 = SellProducts($OrderNumber , $ProductNumber, $Quantity,$SellingPrice);

$cash;
$result8 = EndOrder($cash , $OrderNumber);

//------------------------------------------------------
//Inventory:
$note;
$result9 = NewInventoryProcess($note);

$InventoryNumber;
$result10 = knowInventory();
if($result10)
{
    while($row = mysqli_fetch_assoc($result10))
    {
        $InventoryNumber =  $row['inventoryNumber'];
    }
}

$result11 = increase_quantity($Quantity , $ProductNumber);
//$Cash += $Price;

$result12 = EnterProducts($InventoryNumber , $ProductNumber, $Quantity,$Price);
$result13 = EndInventory($InventoryNumber , $cash);


$result14 = AddProduct($Barcode , $EnglishName, $ArabicName);

$result15 = ProductNumber($Barcode);
if($result15)
{
    while($row = mysqli_fetch_assoc($result15))
    {
        $ProductNumber =  $row['Productnumber'];
    }
}

$result16 = AddProductInfo($SellingPrice , $ExpirationDate, $ProductNumber);

$result17 = EditProductPrice($ProductNumber, $Price);


$result18 = ReturnProduct($ProductNumber , $Quantity, $SellingPrice);

// $result19 = CheckConfCode($pass);
// if($result19)
// {
//     while($row = mysqli_fetch_assoc($result19))
//     {
//         $Type =  $row['Type'];
//     }
// }