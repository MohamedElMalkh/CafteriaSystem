<?php

// $servername = "localhost";
// $username = "root";
// $password = "";
// $db = "ZC_Cafetria";
// // Create connection
// $conn = mysqli_connect($servername, $username, $password, $db );
$conn = new mysqli("localhost", "root", "", "zc_cafetria");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

//This function is used to sign in for different users
function SignIn($email , $password){
    $sql = "CALL SignIn('$email','$password');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return $result;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to get all products' info (Arabic name)
function ProductArabiaInfo(){ 
    $sql = "CALL ProductArabiaInfo();";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        
        return $result;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to get product;s info for each barcode
function ProductBarCodeInfo($barcode){
    $sql = "CALL ProductBarCodeInfo('$barcode');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return $result;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//Order:
//This function is used to create an order 
function createOrder(){ 
    $sql = "CALL CreateOrder();";
    $sql_query = $sql;
    $result = mysqli_query($GLOBALS['conn'],$sql_query);
    if($result) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to know the current order number
function KnowOrder(){ 
    $sql = "CALL KnowOrder();";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return $result; //order number
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to decrease products' quantity from the store per each order
function decrease_quantity($quantity , $product_number){
    $sql = "CALL decrease_quantity('$quantity','$product_number');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to add order's details
function SellProducts($order_number , $product_number, $quantity,$selling_price){ 
    $sql = "CALL SellProducts('$order_number','$product_number', '$quantity','$selling_price');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to define the order total cash and end the order
function EndOrder($cash , $order_number){
    $sql = "CALL EndOrder('$cash','$order_number');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}

//This function is used to check the confirmation code
function CheckConfCode($pass){
    $sql = "CALL CheckConfCode('$pass');";
    $sql_query = $sql;
    $result = mysqli_query($GLOBALS['conn'],$sql_query);
    if($result) 
    {
        echo 'done';
        return $result;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//--------------------------------------------------------------------------
//Inventory:

//This function is used to create an inventory process 
function NewInventoryProcess($note){ 
    $sql = "CALL NewInventoryProcess('$note');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to know the current inventory number 
function knowInventory(){ 
    $sql = "CALL knowInventory();";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return $result; //Inventory number
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to increase products' quantity in the store per each inventory process
function increase_quantity($quantity , $product_number){
    $sql = "CALL increase_quantity('$quantity','$product_number');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to add inventory's details
function EnterProducts($inventory_number , $product_number, $quantity,$price){ 
    $sql = "CALL EnterProducts('$inventory_number','$product_number', '$quantity','$price');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to define the inventory total cash and end the process
function EndInventory($inventory_number , $cash){
    $sql = "CALL EndInventory('$inventory_number','$cash');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}

//--------------------------------------
//Mr. Sherief
// This function is used to add new product's static info
function AddProduct($Barcode , $English_Name, $Arabic_Name){
    $sql = "CALL AddProduct('$Barcode','$English_Name','$Arabic_Name');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to know the current product number
function ProductNumber($Barcode){ 
    $sql = "CALL ProductNumber('$Barcode');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return $result; //product number
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
// This function is used to add new product's dynamic info
function AddProductInfo($selling_price , $expiration_date, $product_number){
    $sql = "CALL AddProductInfo('$selling_price','$expiration_date','$product_number');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
//This function is used to edit product's price
function EditProductPrice($product_number, $price){ 
    $sql = "CALL EditProductPrice('$product_number','$price');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}
// This function is used to return products to the store (Should increase product's quantity after returning it using increase_quantity function)
function ReturnProduct($product_number , $quantity, $selling_price){
    $sql = "CALL ReturnProduct('$product_number','$quantity','$selling_price');";
    $sql_query = $sql;
    if($result = mysqli_query($GLOBALS['conn'],$sql_query)) {
        echo 'done';
        return true;
    }
    else
    {
        echo("Error description: " . $GLOBALS['conn'] -> error);
        return false;
    }
}




function clearStoredResults()
 { //global GLOBALS['conn']; 
    do{ if ($res = $GLOBALS['conn']->store_result()) { $res->free(); } } 
    while ($GLOBALS['conn']->more_results() && $GLOBALS['conn']->next_result()); }
