<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./test.css">
    <title>Document</title>
</head>

<body>
    <!-- add the menue -->

    <?php include_once './Menue.php' ?>
    <form action="">
        <div>
            <label for="bar">Barcode</label>
            <input type="text" name="barcode" id="bar" placeholder="1578562145697" value="" required>
        </div>

        <div>
            <label for="Ar">Name in Arabic</label>
            <input type="text" name="Ar" id="Ar" placeholder="كنز بيبسى" value="" required>
        </div>

        <div>
            <label for="En">Name in English</label>
            <input type="text" name="En" id="En" placeholder="Pepsi Can" value="" required>
        </div>


        <div>
            <label for="customer">Price for the customer</label>
            <input type="Number" name="customer" id="customer" min="0" placeholder="5 LE" value="" required>
        </div>


        <button>save</form>
</body>

</html>