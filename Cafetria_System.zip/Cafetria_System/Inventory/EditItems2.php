<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EditItem2</title>
    <link rel="stylesheet" href="./test.css">
</head>

<body>
    <!-- add the menue -->
    <?php include_once './Menue.php'?>

    <form action="">
        <?php
        $barcode = 5555;
        $productNameAr = "عصير جوافة";
        $productNameEn = "Guava juice";
        $sellingPrice = 100;
        $buyingPrice = 50;
        $exp = "2020-12-01";
        echo"
        <div>
            <label for='bar'>Barcode</label>
            <input type='text' name='barcode' id='bar' placeholder='1578562145697' value='$barcode' required>
        </div>
        
        <div>
            <label for='Ar'>Name in Arabic</label>
            <input type='text' name='Ar' id='Ar' placeholder='كنز بيبسى' value='$productNameAr' required>
        </div>
        
        <div>
            <label for='En'>Name in English</label>
            <input type='text' name='En' id='En' placeholder='Pepsi Can' value='$productNameEn' required>
        </div>
        

        <div>
            <label for='customer'>Price for the customer</label>
            <input type='Number' name='customer' id='customer' min='0' placeholder='5 LE' value='$sellingPrice' required>
        </div>

        <div>
            <label for='customer'>Price paid to buy</label>
            <input type='Number' name='customer' id='paid' min='0' placeholder='1000 LE' value='$buyingPrice' required>
        </div>

        <div>
            <label for='customer'>Expiration Date</label>
            <input type='date' name='customer' id='exp' min='0' placeholder='10-5-2020' value='$exp' required>
        </div>"
        ?>


            <button>save</form>
        </body>
        </html>