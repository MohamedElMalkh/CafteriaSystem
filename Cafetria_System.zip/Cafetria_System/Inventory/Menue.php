<!-- <div class = "navbar"> -->
<nav id="Done">
    <ul>
        <li>
            <a href="./NewInventory.php">
            New Inventory
            </a>
        </li>

        <li>
            <a href="./AddNewItem.php">
            New Item
            </a>
        </li>

        <li>
            <a href="./editItems.php">
            Edit Items
            </a>
        </li>

        <li>
            <a href="../Index.php">
            logout
            </a>
        </li>
    </ul>
</nav>

<!-- 
</div> -->