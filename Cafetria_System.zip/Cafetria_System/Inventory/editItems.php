<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Items</title>
    <link rel="shortcut icon" href="/images/_WEBSITE_ICON.svg">
    <link rel="stylesheet" href="./main_patient.css">
    <link rel="stylesheet" href="./dashboard.css">
    <link href='https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.13.1/css/all.css' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
        nav {
            
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 1.875rem;
        }

        nav>ul>li {
            display: inline;
            align-items: left;
            justify-content: space-between;
            /* margin-top: 1.875rem; */
            padding-inline: 50px;
            padding-top: 20px;
            padding-bottom: 20px;
            border-bottom: 5PX solid #0060df;
            /* background-color: #dcdcdc; */
        }

        .navbar {
            width: 800px;
            background-color: #f1f1f1;
        }

        a {
            font-size: bold;
        }

        #flex {
            display: flex;
            margin: 20px;
        }

        #lab {
            padding: 10px;
        }

        #Done {
            justify-content: center;
            margin-bottom: 50px;
        }
        .data-titles{
            justify-content: center;
        }
        #long{
            margin-left: 110px;
        }
        </style>
</head>

<body>
    <?php
    if(isset($_GET['error'])){
        if($_GET['error'] == "noData"){
            echo "<script>alert('Error: No Added Data!')</script>";
        }
    }
    ?>


<?php include_once './menue.php' ?>
<main class="container ">
    <form action="#" method="GET">
        
        <div class="data-titles patient-grid">
            <input type="checkbox" name="select-all" id="select-all">
            <h3 id="long">Item Name</h3>
            <h3>Buying price</h3>
            <h3>selling price</h3>
            <h3>Amount</h3>
        </div>
        <div class="patients-list">
            <?php
            include_once 'C:\xampp\htdocs\Cafetria_System\ConnectDB_ZC_Cafe.php';
            ob_start();
            clearStoredResults();
            $total = 0;
            $ProductNumber;$ArabicName; $SellingPrice; $Quantity;
            $result2 = ProductArabiaInfo();
            if($result2)
            {
                while($row = mysqli_fetch_assoc($result2))
                {
                    $total++;
                    $ProductNumber =  $row['PNumber'];
                    $ArabicName =  $row['ArabicName'];
                    $SellingPrice =  $row['SellingPrice'];
                    $Quantity =  $row['Quantity'];
                echo
                "
                <div class='patient' id='p1'>
                    <input type='checkbox' name='p1' id='p1'>
                    <a href='#' class='no-eff'><img class='logo profile-pic' src='/images/default_pic.jpg' alt=''></a>
                    <div class='personal-info'>
                        <h1>$ArabicName</h1>
                    </div>
                        <p>$SellingPrice</p>
                    <h2 class='phone'>$Quantity</h2>
                    <h2 class='city'>$ProductNumber</h2>
                   
                    
                    <!-- <button name='db$total' class='no-eff'><i class='fa fa-trash delete-me'></i></button> -->
                        <button name='b$total'><i class='fa fa-ellipsis-h delete-me'></i></button>
                        <input type='number' name='q$total' id='Pat_ID'value='$ProductNumber' style='display: none;'\>
                    </div>
                    ";
                } 
            } 
            else{echo "Error";}
            //////////////////////////////////////////////////////////////////////////////////////////
            for($i=1; $i<=$total;$i++){
                if(isset($_GET["b$i"])){
                    $ProductNumber = $_GET["q$i"];
                    session_start();
                    $_SESSION['vidi'] = $phys_id;
                    header("Location:./editItems2.php?productNumber=$ProductNumber");
                }
             
            }
            ob_end_flush();
            ?>
            </div>
            </div>
        </form>
    </main>
</body>

</html>