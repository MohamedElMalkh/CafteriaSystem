<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="../Inventory/test.css">
    <title>New Inventory</title>
    <style>
        #num{
            padding: 10px;
            width: 100%;
            border-radius: 10px;
        }
    </style>

</head>

<body>

    <?php  include_once './Menue.php'; ?>
    <div class="flex">
        <label for="m1">Search</label>
        <input type="search" list="m1" id="name" name="productSearch">
        <!-- <button name="chosen">click</button> -->
        <datalist id="m1">
            <option value="1">Pepsi</option>
            <option value="2">Chepsi</option>
            <option value="3">Ulcer</option>
        </datalist>
    </div>
    <form action="" method="">
        <div id="myform">
            <table>

                <tr>
                    <td>Price</td>
                    <td><input type="text" id="age">
                        <input type="button" id="add" value="Add" onclick="Javascript:addRow()"></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            </table>
        </div>
        <div id="mydata">
            <b>New Inventory</b>
            <table id="myTableData" border="1" cellpadding="2">
                <tr>
                    <td><b>Product Name</b></td>
                    <td><b>Price of selling</b></td>
                    <td><b>Price of buying</b></td>
                    <td><b>Amount</b></td>
                    <td>&nbsp;</td>
                </tr>
            </table>
            &nbsp;

        </div>
        <!-- <div id="myDynamicTable">
        <input type="button" id="create" value="Click here" onclick="Javascript:addTable()"> to create a Table and add some data using JavaScript
    </div> -->
        <button>Finish</button>
    </form>

    <script src="../JS/Inventory.js"></script>
</body>

</html>