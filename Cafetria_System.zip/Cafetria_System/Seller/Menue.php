<!-- <div class = "navbar"> -->
    <nav id="Done">
        <ul>
            <li >
                <a href="./Selling.php">
                البيع
                </a>
            </li>
            <li >
                <a href="./Finish.php">
                انهاء اليوم
            </a>
        </li>
        
        <li >
            <a href="../Index.php">
            تسجيل خروج
        </a>
    </li>
</ul>
</nav>

<!-- 
</div> -->
