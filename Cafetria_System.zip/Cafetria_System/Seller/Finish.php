<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>finish</title>
    <link rel="stylesheet" href="../Inventory/test.css">
</head>

<body>
    <?php include_once './Menue.php'; ?>
    <div id="flex">
        <input type="number" placeholder="0" id="today" value="" disabled>
        <label id="lab" for="today">ايراد اليوم</label>
    </div>

    <form action="../PHPF/ConfirmationCode.php" method="GET">

        <div>
            <label for=""> Enter the password</label>
            <input type="password" name="pass" id="" placeholder="**********">
        </div>
        <button>login</button>
    </form>
</body>

</html>