<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivering Money</title>
    <link rel="stylesheet" href="../Inventory/test.css">
</head>

<body>
    <!-- the menue here -->
    <?php include_once './Menue.php'; ?>

    <form  action="#" method="GET">
        <div >

            <div>
                <label for="">Required Money for the day</label>
                <input type="Number" name="" id="" placeholder="0 LE" disabled>
            </div>

            <div>
                <label for="">Required Money from previous times</label>
                <input type="Number" name="" id="" placeholder="0 LE" disabled>
            </div>

            <div>
                <label for="">Total Required</label>
                <input type="Number" name="" id="" placeholder="0 LE" disabled>
            </div>

            <div>
                <label for="">Delivered Money</label>
                <input type="Number" name="delivered" id="" min="0" placeholder="0 LE">
            </div>

            <div>
                <button>Done</button>
            </div>
        </div>
    </form>
</body>

</html>