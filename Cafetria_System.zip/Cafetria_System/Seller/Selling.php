<!DOCTYPE html>
<html lang="Ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="../Inventory/test.css">
    <title>لبيع</title>

</head>

<body>

    <?php  include_once './Menue.php'; ?>
    <div class="flex">
        <label for="m1">بحث</label>
        <input type="search" list="m1" id="name" name="productSearch">
        <!-- <button name="chosen">click</button> -->
        <datalist id="m1">
            <option value="1">بيبسى</option>
            <option value="2">شيبسى</option>
            <option value="3">اولكر</option>
            <option value="1">بيبسى</option>
            <option value="2">شيبسى</option>
            <option value="3">اولكر</option>
            <option value="1">بيبسى</option>
            <option value="2">شيبسى</option>
            <option value="3">اولكر</option>
            <option value="1">بيبسى</option>
            <option value="2">شيبسى</option>
            <option value="3">اولكر</option>
        </datalist>
    </div>
    <form action="" method="">
    <div id="myform">
        <table>
            
            <tr>
                <td>السعر</td>
                <td><input type="text" id="age" hidden>
                    <input type="button" id="add" value="Add" onclick="Javascript:addRow()"></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
        </table>
    </div>
    <div id="mydata">
        <b>فاتورة الشراء</b>
        <table id="myTableData" border="1" cellpadding="2">
            <tr>
                <td><b>اسم المنتج</b></td>
                <td><b>السعر</b></td>
                <td><b>الكمية</b></td>
                <td>&nbsp;</td>
            </tr>
        </table>
        &nbsp;

    </div>
    <!-- <div id="myDynamicTable">
        <input type="button" id="create" value="Click here" onclick="Javascript:addTable()"> to create a Table and add some data using JavaScript
    </div> -->
        <button>انهاء</button>
    </form> 
   
    <script src="../JS/seller.js"></script>
</body>

</html>