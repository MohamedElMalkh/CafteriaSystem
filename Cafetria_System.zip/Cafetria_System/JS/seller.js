function addRow() {

    var myName = document.querySelector("#name");
    var age = document.getElementById("age");
    var table = document.getElementById("myTableData");

    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);

    row.insertCell(0).innerHTML = myName.value;
    row.insertCell(1).innerHTML = age.value;
    row.insertCell(2).innerHTML = '<input type="number" name="">';
    row.insertCell(3).innerHTML = '<input type="button" value = "الغاء" onClick="Javacsript:deleteRow(this)">';

}

function deleteRow(obj) {

    var index = obj.parentNode.parentNode.rowIndex;
    var table = document.getElementById("myTableData");
    table.deleteRow(index);

}


function load() {

    console.log("Page load finished");

}