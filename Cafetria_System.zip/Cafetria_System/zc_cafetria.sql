-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2021 at 10:41 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zc_cafetria`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddProduct` (IN `Barcod` VARCHAR(200), IN `English` VARCHAR(200), IN `Arabic` VARCHAR(200))  INSERT INTO 
product_names(Barcode, EnglishName, ArabicName)
VALUES(Barcod, English, Arabic)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddProductInfo` (IN `price` DOUBLE, IN `expdate` DATE, IN `ProductNo` BIGINT)  INSERT INTO
products(PNumber, SellingPrice, ExpirationDate, Quantity)
VALUES(ProductNo, price, expdate, 0)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateOrder` ()  INSERT INTO orders(TotalCash)
Values (0)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `decrease_quantity` (IN `Quant` BIGINT, IN `ProductNo` BIGINT)  UPDATE products
SET products.Quantity = (products.Quantity - Quant)
WHERE products.PNumber = ProductNo$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditProductPrice` (IN `productNo` BIGINT, IN `NewPrice` DOUBLE)  UPDATE products
SET products.SellingPrice = NewPrice
WHERE products.PNumber = productNo$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EndInventory` (IN `invNo` BIGINT, IN `cash` DOUBLE)  UPDATE inventory
SET TotalCash = cash
WHERE inventory.inventoryNumber = invNo$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EndOrder` (IN `cash` DOUBLE, IN `OrderNo` BIGINT)  UPDATE orders
SET TotalCash = cash
WHERE orders.OrderNumber = OrderNo$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EnterProducts` (IN `InvNo` BIGINT, IN `ProductNo` BIGINT, IN `Quantit` BIGINT, IN `Price` DOUBLE)  INSERT INTO inventorydetails(InvNumber,ProductNumber,Quantity, Price)
Values (InvNo,ProductNo,Quantit,Price)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `increase_quantity` (IN `Quant` BIGINT, IN `ProductNo` BIGINT)  UPDATE products
SET products.Quantity = (products.Quantity + Quant)
WHERE products.PNumber = ProductNo$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `knowInventory` ()  SELECT inventoryNumber
FROM inventory
WHERE TotalCash = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `KnowOrder` ()  SELECT Number
FROM orders
WHERE TotalCash = 0$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `NewInventoryProcess` (IN `note` VARCHAR(200))  INSERT INTO inventory(Notes, TotalCash)
Values (note,0)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProductArabiaInfo` ()  SELECT products.PNumber, product_names.ArabicName, products.SellingPrice, products.Quantity
FROM product_names, products
WHERE product_names.Productnumber = products.PNumber$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProductBarCodeInfo` (IN `BarCode` VARCHAR(200))  SELECT Productnumber, Arabicname, SellingPrice, Quantity
FROM products, product_names
WHERE BarCode = product_names.Barcode AND products.PNumber = product_names.Productnumber$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProductNumber` (IN `BarCode` VARCHAR(200))  SELECT product_names.Productnumber
FROM product_names
WHERE product_names.Barcode = BarCode$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ReturnProduct` (IN `productNo` BIGINT, IN `Quant` BIGINT, IN `Price` DOUBLE)  INSERT INTO
returnproducts(ProductNumber,Quantity,SellingPrice)
VALUES(productNo, Quant, Price)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SellProducts` (IN `OrderNo` BIGINT, IN `ProductNo` BIGINT, IN `Quantit` BIGINT, IN `Price` DOUBLE)  INSERT INTO orderdetails(OrderNumber,ProductNumber,Quantity, SellingPrice)
Values (OrderNo,ProductNo,Quantit,Price)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SignIn` (IN `user` VARCHAR(200), IN `Pass` VARCHAR(200))  SELECT AccountType
FROM account
WHERE Username = user AND Password = Pass$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Type` smallint(6) NOT NULL,
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Type`, `Username`, `Password`) VALUES
(1, 'Sara@zewailcity.edu.eg', 'sara1234'),
(2, 'Marwa@zewailcity.edu.eg', 'marwa1234'),
(3, 'Sherief@zewailcity.edu.eg', 'sherief1234'),
(4, 'Essam@zewailcity.edu.eg', 'Essam1234');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventoryNumber` bigint(20) NOT NULL,
  `TotalCash` double NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Notes` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventorydetails`
--

CREATE TABLE `inventorydetails` (
  `InvNumber` bigint(20) NOT NULL,
  `Price` double NOT NULL,
  `Quantity` bigint(20) NOT NULL,
  `ProductNumber` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderNumber` bigint(20) NOT NULL,
  `ProductNumber` bigint(20) NOT NULL,
  `SellingPrice` double NOT NULL,
  `Quantity` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Number` bigint(20) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp(),
  `TotalCash` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `PNumber` bigint(20) NOT NULL,
  `SellingPrice` double NOT NULL,
  `ExpirationDate` date NOT NULL,
  `Quantity` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product_names`
--

CREATE TABLE `product_names` (
  `Productnumber` bigint(20) NOT NULL,
  `Barcode` varchar(200) NOT NULL,
  `EnglishName` varchar(200) NOT NULL,
  `ArabicName` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `returnproducts`
--

CREATE TABLE `returnproducts` (
  `ProductNumber` bigint(20) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Quantity` bigint(20) NOT NULL,
  `SellingPrice` double NOT NULL,
  `ReturnNumber` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Type`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventoryNumber`);

--
-- Indexes for table `inventorydetails`
--
ALTER TABLE `inventorydetails`
  ADD PRIMARY KEY (`InvNumber`,`ProductNumber`),
  ADD KEY `inv_ibfk_2` (`ProductNumber`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderNumber`,`ProductNumber`),
  ADD KEY `orders_ibfk_2` (`ProductNumber`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Number`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`PNumber`);

--
-- Indexes for table `product_names`
--
ALTER TABLE `product_names`
  ADD PRIMARY KEY (`Productnumber`),
  ADD UNIQUE KEY `Barcode` (`Barcode`),
  ADD UNIQUE KEY `Barcode_2` (`Barcode`);

--
-- Indexes for table `returnproducts`
--
ALTER TABLE `returnproducts`
  ADD PRIMARY KEY (`ReturnNumber`),
  ADD KEY `return_ibfk_1` (`ProductNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventoryNumber` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Number` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_names`
--
ALTER TABLE `product_names`
  MODIFY `Productnumber` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `returnproducts`
--
ALTER TABLE `returnproducts`
  MODIFY `ReturnNumber` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventorydetails`
--
ALTER TABLE `inventorydetails`
  ADD CONSTRAINT `inv_ibfk_1` FOREIGN KEY (`InvNumber`) REFERENCES `inventory` (`InventoryNumber`),
  ADD CONSTRAINT `inv_ibfk_2` FOREIGN KEY (`ProductNumber`) REFERENCES `product_names` (`ProductNumber`);

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`OrderNumber`) REFERENCES `orders` (`Number`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`ProductNumber`) REFERENCES `product_names` (`ProductNumber`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`PNumber`) REFERENCES `product_names` (`ProductNumber`);

--
-- Constraints for table `returnproducts`
--
ALTER TABLE `returnproducts`
  ADD CONSTRAINT `return_ibfk_1` FOREIGN KEY (`ProductNumber`) REFERENCES `product_names` (`ProductNumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
