<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./Inventory/test.css">
    <style>
        #index{
            margin-top: 110px;
        }
    </style>
</head>

<body id="index">
    <form action="PHPF\login.php" method="GET">
        <div>
            <label for=""> User Name</label>
            <input type="text" name="e_mail" id="">
        </div>

        <div>
            <label for="">password</label>
            <input type="password" name="pass" id="">
        </div>

        <div>
            <button>login</button>
        </div>
    </form>
</body>

</html>