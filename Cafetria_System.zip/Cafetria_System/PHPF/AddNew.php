<?php

$barcode = $_GET['barcode'];
$Ar = $_GET['Ar'];
$En = $_GET['En'];
$amount = $_GET['amount'];
$paid = $_GET['paid']; /// not added 
$price = $_GET['customer'];
$exp = $_GET['exp'];
$note = $_GET['note'];
$InventoryNumber = -1;

$result14 = AddProduct($barcode , $En, $Ar);

$result15 = ProductNumber($Barcode);
if($result15)
{
    while($row = mysqli_fetch_assoc($result15))
    {
        $ProductNumber =  $row['Productnumber'];
    }
}

$result16 = AddProductInfo($price , $Exp, $ProductNumber);

$result11 = increase_quantity($amount , $ProductNumber);
$result9 = NewInventoryProcess($note);
$result10 = knowInventory();
if($result10)
{
    while($row = mysqli_fetch_assoc($result10))
    {
        $InventoryNumber =  $row['inventoryNumber'];
    }
}
$result12 = EnterProducts($InventoryNumber , $ProductNumber, $amount,$paid);
$result13 = EndInventory($InventoryNumber , $Totalpaid);
