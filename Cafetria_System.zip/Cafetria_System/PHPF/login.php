
<?php

include_once 'C:\xampp\htdocs\Cafetria_System\ConnectDB_ZC_Cafe.php';

$email = $_GET['e_mail'];
$password = $_GET['pass'];
#$email = "Sara@zewailcity.edu.eg";
#$password = 'sara1234';

$pass = false;
$UserType = 5;

echo "Hello";
$result = SignIn($email , $password);


#$result = signIn('$email' , '$password');
if($result)
{
    while($row = mysqli_fetch_assoc($result)){
        $UserType = $row['Type'];
        $pass = true;
    }
   
}
else{
    echo "Error";
}


    session_start();
    $_SESSION['Type'] = $UserType;


    if($pass && $UserType == 1) // Mrs Sara
    {
        header("Location:../MrsSara/Dashboard.php");
    }
    elseif($pass && $UserType == 2) //Mrs Marwa
    {
        header("Location:../MrsMarwa/Dashboard.php");   
    }
    elseif($pass && $UserType == 3) // Mr Sherief
    {
        header("Location:../Inventory/NewInventory.php");   
    }
    elseif($pass && $UserType == 4) // 3m 3sam
    {
        header("Location:../Seller/Selling.php");
    }
    else{
        
        header("Location:../Index.php? error=NoUser");
    }