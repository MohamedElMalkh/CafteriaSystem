<?php

include_once '../ConnectDB_ZC_Cafe.php';

$delivered = $_GET['delivered'];

// here the procedure of delivering the money