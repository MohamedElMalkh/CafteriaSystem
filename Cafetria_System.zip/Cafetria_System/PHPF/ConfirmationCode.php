<?php
include_once '../ConnectDB_ZC_Cafe.php';
$Type = 5;

$pass = $_GET['pass'];
$result = CheckConfCode($pass);
if ($result)
{
    while($row = mysqli_fetch_assoc($result)){
        $Type = $row['Type'];
    }
   
}
else{
    echo "Error";
}



if($Type == 1 ||  $Type == 2 || $Type == 3){
    echo $Type;
    header("Location:../Seller/DeliveringMoney.php");
}
else
{
    echo $Type;
    header("Location:../Seller/Finish.php? error=NoUser");
}